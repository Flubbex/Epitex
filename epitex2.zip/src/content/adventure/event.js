const eventConstructor = (API) => {
    
    const clear = () => API.clear()

    const villageElderQuest = async (room,ent) => {
        switch(API.questFlag("villageElderQuest")){
            case null:
                API.questFlag("villageElderQuest","quest_in_progress")
                API.startQuest("villageElderQuest1",room,ent)
                break
            case 1: //Waiting for the poop bowl
                API.startQuest("villageElderQuest1B",room,ent)
                break
            case 2: //Poop bowl in inventory
                API.questFlag("villageElderQuest","quest_in_progress")
                API.startQuest("villageElderQuest2",room,ent)
                break
            
        }
    }

    const yourTentInit = async (room,ent) => {
        API.startQuest("yourTentInit",room,ent)
    }

    return  {clear,yourTentInit,villageElderQuest}
}

export default eventConstructor