import adventure from "./adventure"
import test from "./test"

export default [adventure,test]