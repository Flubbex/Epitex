//Bomb-ass logo generated using https://patorjk.com/software/taag/

const banana = `<img src='img/banana.gif' onClick="game.handle('bananaclicked',true)" width="64" height="64" style="display:inline;hover:cursor;"/>`
const epiTextLogo = 
`                                        
 ▄▄▄▄▄▄▄▄               ██                                  
 ██▀▀▀▀▀▀               ▀▀       ██                         
 ██        ██▄███▄    ████     ███████    ▄████▄   ▀██  ██▀ 
 ███████   ██▀  ▀██     ██       ██      ██▄▄▄▄██    ████   
 ██        ██    ██     ██       ██      ██▀▀▀▀▀▀    ▄██▄   
 ██▄▄▄▄▄▄  ███▄▄██▀  ▄▄▄██▄▄▄    ██▄▄▄   ▀██▄▄▄▄█   ▄█▀▀█▄  
 ▀▀▀▀▀▀▀▀  ██ ▀▀▀    ▀▀▀▀▀▀▀▀     ▀▀▀▀     ▀▀▀▀▀   ▀▀▀  ▀▀▀ 
           ██                                               
    v0.2                         made by Flubber  ${banana}
`

/**
 * Sets up base content required by the engine, along with some fun stuff.
 * @param {*} API
 * @returns Base content Pack
 */
const engineContentConstructor = (API) => {

    const room = [
        {
            id:"NULLED",
            type:"room",
            name:"Null Room",
            description:"You find yourself in a place beyond space and time."
        },
         {
            id:"LoaderMenu",
            type:"menu",
            name:"Load Screen",
            description:epiTextLogo,
            event:{
                playerViewed:["loadMenu"]
            }
        }
    ]

    const loadMenu = ()=>{
        API.print("")
        API.print("Available adventures:")
        const packSet = API.getContentPackSet()
        packSet.map((pack)=>{
            const {name} = pack.info
            API.print(`<button onClick="game.handle('loadGame ${name}',true)">${name}</button>`)
        })
    }

    const bananaClicked = ()=>{
        API.print("Why you touching my banana bro?")
    }

    const loadGame = (gameSplit) => {
        const game = gameSplit.join(" ")
        API.loadGamePack(game)
    }
    return {
        info:{
            name:"Base content pack",
            description:"Basic content every text adventure engine should never go without.",
            version:1,
            startRoom:"LoaderMenu"
        },
        room,
        enemy:[],
        item:[],

        quest:{},
        event:{loadMenu},
        command:{loadgame:loadGame,bananaclicked:bananaClicked},
        action:{}
    }
}
export default engineContentConstructor