class Emitter {
    call = {}

    on(ev,call){
        this.call[ev] = this.call[ev] ? this.call[ev].concat(call) : [call]
    }

    off(ev,call){
        if (this.call[ev])
            this.call[ev] = this.call[ev].filter((e)=>e!==call)
    }

    emit(ev,...arg){
        if (this.call["*"])
            this.call["*"].map((call)=>call(ev,...arg))
        if (this.call[ev])
            this.call[ev].map((call)=>call(...arg))
    }

    toJSON(){
        return null
    }
       
}

export default Emitter