import Being from "./being"

class Player extends Being {

    type = "player"
    healTick = 0
    maxHealTick= 2
    room = "NULLED"
    locked = false 
    lockedMessage = "You feel compelled to stay where you are"
    quest = {}

    constructor(state={}){
        super(state)
        this.room = state.room ?? this.room
        this.quest = state.quest ? {...state.quest} : this.quest
    }
    
     move(nextRoom,currentRoom){
        this.room = nextRoom.id

        if (currentRoom.event["playerLeft"])
            currentRoom.emit("event", currentRoom.event["playerLeft"], currentRoom, this)
        
        if (nextRoom.event["playerEntered"])
            nextRoom.emit("event", nextRoom.event["playerEntered"], nextRoom, this)
        
        this.emit("moved",nextRoom,currentRoom)
    }
    
    tick(game){
        if (this.health <= 0)
            return game.print("Your body slowly decays")
        if (this.health < this.statistic.maxHealth)
        {
            this.healTick++
            if (this.healTick >= this.maxHealTick)
            {
                this.health++
                this.healTick = 0
            }
        }
    }

    calculateStatistic(modifier={}){
        modifier.constitution = modifier.constitution ? modifier.constitution+10 : 10
        return super.calculateStatistic(modifier)
    }

}

export default Player